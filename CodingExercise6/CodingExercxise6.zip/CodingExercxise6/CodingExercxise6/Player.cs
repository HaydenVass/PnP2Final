﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingExercxise6
{
    class Player :IComparable<Player>
    {
        public string Name { get; set; }
        public List<Cards> CardHand { get; set; }
        public int TotalCardPoints { get; set; }

        public Player(string _name)
        {
            CardHand = new List<Cards>();
            Name = _name;

        }

        public int CompareTo(Player other)
        {
            return TotalCardPoints.CompareTo(other.TotalCardPoints);
        }
    }
}
