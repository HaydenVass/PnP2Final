﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingExercxise6
{
    class Menu
    {
        private bool running = true;
        private int choice;
        private bool shuffleCheck = true;
        private bool dealCheck = true;
        private List<Player> playerList = new List<Player>();
        public List<Cards> Deck = new List<Cards>();
        Random random = new Random();

        public Menu()
        {
            CreateDeck();
            SwitchStatement();
        }

        public void SwitchStatement()
        {
            CreatePlayers();

            do
            {
                Console.WriteLine("The goal of the game is to have the " +
                "highest points out of the all the players. Number cards have the same amount of points as the number they are." +
                "Jacks, Queens and Kings are woth 12 points and Aces are worth 15.");
                DisplayMenu();
                switch (choice)
                    {
                        case 1:
                            {
                            ShuffleDeck();
                                Validation.ConsoleClear();
                            }
                            break;
                        case 2:
                            {
                            if(shuffleCheck == true)
                            {
                                Console.WriteLine("Please shuffle the deck first.");
                                Validation.ConsoleClear();
                            }
                            else
                            {
                                Deal2();
                                AddPoints();
                                Console.WriteLine("The cards have been delt and the points have been added up! Press option 3 to see the winner!");
                                Validation.ConsoleClear();
                            }
                            }
                            break;
                        case 3:
                            {
                            if (dealCheck == true)
                            {
                                Console.WriteLine("please deal some cards first.");
                            }
                            else
                            {
                                CheckHands();
                            }
                            }
                            break;
                        case 4:
                            {
                                Console.WriteLine("good bye");
                                running = false;
                            }
                            break;
                    default:
                            Console.WriteLine("Please choose a valid sign.");
                            Validation.ConsoleClear();
                            break;

                    }
            } while (running == true);

        }
        public void CheckHands()
        {
            Console.WriteLine("---------");
            playerList.Sort();
            playerList.Reverse();
            Console.WriteLine("And the Winner is.........");
           foreach(Player player in playerList)
            {
                Console.WriteLine(player.Name);
                foreach (Cards card in player.CardHand)
                {
                    if(card.Value == 0 || card.Value==1|| card.Value==11 || card.Value == 12)
                    {
                        Console.WriteLine($"{card.Name} {card.Suit}");
                    }
                    else 
                    {
                        Console.WriteLine($"{card.Value} {card.Name} {card.Suit}");
                    }
                }
                Console.WriteLine("Total: "+player.TotalCardPoints);
                Console.WriteLine("-----------");
            }
            Validation.ConsoleClear();
            Console.WriteLine("If you would like to play again, shuffle and re deal the deck. If not, press option 4");
            shuffleCheck = true;
            dealCheck = true;
            Deck = null;
            CreateDeck();
            foreach(Player player in playerList)
            {
                player.TotalCardPoints = 0;
                player.CardHand = new List<Cards>();
            }
            Validation.ConsoleClear();
        }

        public void ShuffleDeck()
        {
            Console.WriteLine("(flipping noise)\nCards shuffled!");
            shuffleCheck = false;
           
        }
        public void Deal2()
        {
            foreach( Player player in playerList)
            {
                for (int i = 0; i < 13; i++)
                {
                    int randomCard = random.Next(Deck.Count);
                    player.CardHand.Add(Deck.ElementAt(randomCard));
                    Deck.RemoveAt(randomCard);
                }
            }
            dealCheck = false;
        }
        private void DisplayMenu()
        {
            Console.WriteLine("Please choose the option you'd like to do.");
            int counter = 0;
            string[] dealer = { "shuffle", "Deal", "Check Winner", "Exit" };
            foreach(string option in dealer)
            {
                counter++;
                Console.WriteLine($"{counter}. {option}");
            }
            choice = Validation.GetIntWithinRange(1,4);

        }
        private void CreatePlayers()
        {
            Console.WriteLine("First lets make some players!");
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine($"Please enter player {i + 1}'s name");
                string playerName = Validation.NullOrEmpty(Console.ReadLine());
                Player player1 = new Player(playerName);
                playerList.Add(player1);

            }
            Console.WriteLine("Those are some great names. Lets get playing!");
            Validation.ConsoleClear();
        }
        public void CreateDeck()
        {
            Deck = new List<Cards>();
            string[] _suits = { "spades", "diamonds", "hearts", "clubs" };
            for (int i = 0; i < 52; i++)
            {
                Cards card = new Cards(i % 13, _suits[i % 4]);
                card.FormulateCard(card);
                Deck.Add(card);
            }
        }
        private void AddPoints()
        {
            foreach(Player player in playerList)
            {
                
                for (int i = 0; i < player.CardHand.Count; i++)
                {
                  player.TotalCardPoints += player.CardHand[i].PointValue;
                }
            }
        }

    }
}
