﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingExercxise6
{
    class Cards
    {
        public string Suit { get; set; }
        public int Value { get; set; }
        public int PointValue { get; set; }
        public string Name { get; set; }
        public List<Cards> Deck = new List<Cards>();

        public Cards(int value, string _suit)
        {
            Value = value;
            Suit = _suit;
        }
        public void FormulateCard(Cards card)
        {
                if (card.Value == 0)
                {
                    card.PointValue = 15;
                    card.Name = "Ace of";
                }
                else if (card.Value ==11)
                {
                    card.PointValue = 12;
                    card.Name = "Jack";
                }
                else if (card.Value == 12)
                {
                    card.PointValue = 12;
                    card.Name = "Queen of";
                }
                else if (card.Value == 1)
                {
                    card.PointValue = 12;
                    card.Name = "King of";
                }
                else
                {
                    card.PointValue = card.Value;
                    card.Name = "of";
                }
        }

    }
}
