﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingExercise1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            SportRemoveList list = new SportRemoveList();
        }
    }
}
