﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VassHayden_CC2_1
{
    class Menu
    {
        private bool running = true;
        private string x;
        private Dictionary<string, List<string>> colorDictionary = new Dictionary<string, List<string>>();
        // list for each color to hold facts
        List<string> Red = new List<string>();
        List<string> Orange = new List<string>();
        List<string> Yellow = new List<string>();
        List<string> Green = new List<string>();
        List<string> Blue = new List<string>();
        List<string> Indigo = new List<string>();
        List<string> Violet = new List<string>();



        public Menu()
        {
            // fills dictionary with colors as keys and facts as values
            FillDictionary();
            SwitchStatement();
        }
        public void SwitchStatement()
        {
            
            // switch statement to run the menu.
            do
            {
                DisplayArray(out x);
                switch (x)
                {
                    case "red":
                        {
                            DisplayFacts("red");
                            Validation.ConsoleClear();
                        }
                        break;
                    case "orange":
                        {
                            DisplayFacts("orange");
                            Validation.ConsoleClear();

                        }
                        break;
                    case "yellow":
                        {
                            DisplayFacts("yellow");
                            Validation.ConsoleClear();

                        }
                        break;
                    case "green":
                        {
                            DisplayFacts("green");
                            Validation.ConsoleClear();
                        }
                        break;
                    case "blue":
                        {
                            DisplayFacts("blue");
                            Validation.ConsoleClear();
                        }
                        break;
                    case "indigo":
                        {
                            DisplayFacts("indigo");
                            Validation.ConsoleClear();
                        }
                        break;
                    case "violet":
                        {
                            DisplayFacts("violet");
                            Validation.ConsoleClear();
                        }
                        break;
                    case "exit":
                        {
                            Console.WriteLine("good bye");
                            running = false;
                        }
                        break;
                    default:
                        Console.WriteLine("Please choose a valid number");
                        Validation.ConsoleClear();
                        break;
                }
            } while (running == true);

        }
        // creates key value pairs for dictionary
        private void FillDictionary()
        {
            AddValues();
            colorDictionary.Add("red", Red);
            colorDictionary.Add("orange", Orange);
            colorDictionary.Add("yellow", Yellow);
            colorDictionary.Add("green", Green);
            colorDictionary.Add("blue", Blue);
            colorDictionary.Add("indigo", Indigo);
            colorDictionary.Add("violet", Violet);
        }
        // adds all the facts to the list then which are added to the dictionary
        private void AddValues()
        {
            Red.Add("-Did you know red means beautiful in Russian?");
            Red.Add("-Did you know the word ruby comes from the Latin word rubens? Which means red.");
            Red.Add("-In Aztec culture, red was connected with blood.");
            Orange.Add("-In the United States Army, orange is the color of the United States Army Signal Corps.");
            Orange.Add("-The interior dash lights on older model Suburu were orange.");
            Orange.Add("-Orange is the national color of the Netherlands because its royal family owns the principality of Orange.");
            Yellow.Add("-Yellow is psychologically the happiest color in the color spectrum.");
            Yellow.Add("-The comic book character Green Lantern was afraid of the color yellow");
            Yellow.Add("-75% of the pencils sold in the United States are painted yellow.");
            Green.Add("-Green was the favorite color of George Washington, the first President of the United States.");
            Green.Add("-Green is the color used for night-vision goggles because the human eye is most sensitive to and able to discern the most shades of that color.");
            Green.Add("-Green is a lucky color in most Western cultures.");
            Blue.Add("-The 1993 film “Blue” consists entirely of the color blue with narration and soundbytes.");
            Blue.Add("-Mosquito’s are attracted to the color blue twice as much as to any other color.");
            Blue.Add("-Alice Blue” is a light blue-gray or steel blue color that was favored by Alice Roosevelt Longworth, daughter of Theodore Roosevelt.");
            Indigo.Add("-Indigo is one of the seven colors of the rainbow.");
            Indigo.Add("-The color indigo is named after the indigo dye derived from the plant Indigofera tinctoria.");
            Indigo.Add("-It is recorded as far back as 1229 in English history that “Indigo” was used as a color name.");
            Violet.Add("-The Byzantine emperor signed edicts in violet ink.");
            Violet.Add("-Leonardo da Vinci believed that the power of meditation increases ten times when done in a violet light");
            Violet.Add("-In stained glass, the color violet is seen as uniting the wisdom.");
        }
        // ask the user if they want to look at another colors facts.
        private void ContinueYesNo()
        {
            Console.WriteLine("Would you like to see the facts of another color?\nYes or No?");
            string choice = Validation.NullOrEmpty(Console.ReadLine().ToLower());
            if(choice == "yes")
            {
                 running = true;
            }
            else if (choice == "no")
            {
                Console.WriteLine("Thank you for using the app. Bye.");
                 running = false;
            }
            else
            {
                Console.WriteLine("Please choose yes or no.");
                choice = Validation.NullOrEmpty(Console.ReadLine().ToLower());
            }
        }
        // method to display each colors fact
        private void DisplayFacts(string colorChoice)
        {
            foreach (KeyValuePair<string, List<string>> color in colorDictionary)
            {
                if (color.Key == colorChoice)
                {
                    foreach (string fact in color.Value)
                    {
                        Console.WriteLine(fact);
                    }

                }
            }
            ContinueYesNo();
        }


    
        public string DisplayArray(out string x)
        {// make two methods. one that inputs for array two that outputs user input
            string[] menuArray = { "Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet", "Exit" };
            for (int i = 0; i < menuArray.Length; i++)
            {
                Console.WriteLine($"{i + 1} {menuArray[i]}");
            }
            Console.WriteLine("Please type the color you would like to run.");
            string userChoice = Validation.NullOrEmpty(Console.ReadLine());
            // validates user string so they can type any case
            userChoice = userChoice.ToLower().Trim();
            return x = userChoice;
        }
    }
}
