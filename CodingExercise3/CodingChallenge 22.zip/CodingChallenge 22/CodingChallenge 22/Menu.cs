﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VassHayden_CC2_2
{
    class Menu
    {
        private string x;
        private bool running = true;
        List<Student> studentList = new List<Student>();
        Student currentStudent = null;

        public Menu()
        {
            CreateStudents();
            SwitchStatement();
        }
        public void SwitchStatement()
        {
            // switch statement to run the menu.
            do
            {
                DisplayArray(out x);
                switch (x)
                {
                    case "1":
                    case "View Students / Classes":
                        {
                            DisplayStudentsAndInfo();
                            Validation.ConsoleClear();
                        }
                        break;
                    case "2":
                    case "View Students total GPA":
                        {
                            ReviewGPA();
                            Validation.ConsoleClear();
                        }
                        break;
                    case "3":
                    case "Edit students grade":
                        {
                            EditGrade();
                        
                        }
                        break;
                    case "4":
                    case "Exit":
                        {
                            running = false;
                        }
                        Console.WriteLine("good bye");
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Please choose a valid number");
                        Validation.ConsoleClear();
                        break;
                }
            } while (running == true);

        }
        // displays students as well as the classes they are in/ letter and number grade as well as GPA for each class.
        public void DisplayStudentsAndInfo()
        {
            Console.WriteLine("Please select the number of the student you would like to edit");
            DisplayStudentsOnly();
            int selection = Validation.GetIntWithinRange(0, studentList.Count);
            // selects student off array element, sets it to current student
            currentStudent = studentList.ElementAt(selection - 1);
            foreach(Courses subject in currentStudent.ClassList)
            {
                Console.WriteLine($"class: {subject.ClassName} grade: {subject.Grade} {subject.GradeLetter} GPA: {subject.GPA}");
            }
            Console.WriteLine($"Total GPA: { AvergeGPA(currentStudent)}");

        }
        // displays only students, used in other methods
        private void DisplayStudentsOnly()
        {
            int counter = 0;
            foreach (Student student in studentList)
            {
                counter++;
                Console.WriteLine($"{counter}. {student.FirstName}");
            }

        }
        // averages a students GPA. Works off currentStudent
        private void ReviewGPA()
        {
            Console.WriteLine("Which Students GPA would you like to see?");
            DisplayStudentsOnly();
            int selection = Validation.GetIntWithinRange(0, studentList.Count);
            currentStudent = studentList.ElementAt(selection - 1);
            Console.WriteLine($"The total GPA for this student is {AvergeGPA(currentStudent)}");
        }
        // takes in user input to change a students grade.
        private void EditGrade()
        {
            Console.WriteLine("Please select the number of the student you would like to edit");
            DisplayStudentsOnly();
            int selection = Validation.GetIntWithinRange(0, studentList.Count);
            // selects student off array element, sets it to current student
            currentStudent = studentList.ElementAt(selection - 1);
            Console.WriteLine("What class would you like to edit?");
            int counter = 0;
            //shows current students classes
            foreach(Courses courses in currentStudent.ClassList)
            {
                counter++;
                Console.WriteLine($"{counter}. {courses.ClassName}");
            }
            int gradeChange = Validation.GetIntWithinRange(0, currentStudent.ClassList.Count);
            Console.WriteLine("What would you like to change the grade to?");
            // validates to 110 just incase theres extra credit.
            double newGrade = Validation.GetDoubleWithinRange(0, 110);
            // changes grade to user input
            currentStudent.ClassList.ElementAt(gradeChange - 1).Grade = newGrade;
            // sets GPA associated with that grade range
            currentStudent.ClassList.ElementAt(gradeChange - 1).sGPA();
            Console.WriteLine("Grade changed");

            Validation.ConsoleClear();
        }
        // method to average students grade
        private double AvergeGPA(Student student)
        {
            double total = 0;
            foreach (Courses course in student.ClassList)
            {
                total += course.GPA;
            }
            return student.GPATotal = total / student.ClassList.Count;
        }

        public string DisplayArray(out string x)
        {// make two methods. one that inputs for array two that outputs user input
            string[] menuArray = { "Review Students", "Review Students Grade /GPA", "Edit Student Grade", "Exit" };
            for (int i = 0; i < menuArray.Length; i++)
            {
                Console.WriteLine($"{i + 1} {menuArray[i]}");
            }
            Console.WriteLine("Please enter the choice you would like to run.");
            string userChoice = Console.ReadLine();
            // validates user string so they can type any case
            userChoice = userChoice.ToLower().Trim();
            return x = userChoice;
        }
        // creates students for project
        public void CreateStudents()
        {
            Student student1 = new Student("Ron", "Swanson");
            Student student2 = new Student("Michael", "Scott");
            Student student3 = new Student("Mary", "Berry");
            Student student4 = new Student("Sophie", "Smith");
            Student student5 = new Student("Steven", "Baker");
            studentList.Add(student1);
            studentList.Add(student2);
            studentList.Add(student3);
            studentList.Add(student4);
            studentList.Add(student5);
        }
    }
}




