﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VassHayden_CC2_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            Menu menu = new Menu();
        }
    }
}
