﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VassHayden_CC2_2
{
    class Courses
    {
        public string ClassName { get; set; }
        public double Grade { get; set; }
        public string GradeLetter { get; set; }
        public double GPA { get; set; }


        public Courses(string _className, double _grade)
        {
            ClassName = _className;
            Grade = _grade;
        }
        // method to set gpa pending grade of class.
        public void sGPA()
        {
            if (Grade > 94.5)
            {
                GPA += 4.00;
                GradeLetter = "A+";
            }
            else if (Grade > 89.5)
            {
                GPA += 3.5;
                GradeLetter = "A-";
            }
            else if (Grade > 84.5)
            {
                GPA += 3.0;
                GradeLetter = "B+";
            }
            else if (Grade > 79.5)
            {
                GPA += 2.5;
                GradeLetter = "B-";
            }
            else if (Grade > 74.5)
            {
                GPA += 2.0;
                GradeLetter = "C+";
            }
            else if (Grade > 69.5)
            {
                GPA += 1.5;
                GradeLetter = "C-";
            }
            else if (Grade > 64.5)
            {
                GPA += 1.0;
                GradeLetter = "D+";
            }
            else if (Grade > 59.5)
            {
                GPA += 0.5;
                GradeLetter = "D-";
            }
            else if (Grade < 59.5)
            {
                GPA += 0;
                GradeLetter = "F";
            }
        }



    }
}
