﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VassHayden_CC2_2
{
    class Student
    {

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public double GPATotal { get; set; }

        public List<Courses> ClassList;
        // takes in first name last name, creates list for each student.
        public Student(string _first, string _last)
        {
            ClassList = new List<Courses>();
            FirstName = _first;
            LastName = _last;
            Courses course1 = new Courses("Science of Hockey", 00);
            Courses course2 = new Courses("Physics of Rugby", 00);
            Courses course3 = new Courses("Chemistry of Swimming", 00);
            Courses course4 = new Courses("Baseball in Art", 00);
            Courses course5 = new Courses("Geometry of Golf", 00);
            ClassList.Add(course1);
            ClassList.Add(course2);
            ClassList.Add(course3);
            ClassList.Add(course4);
            ClassList.Add(course5);


        }




    }
}
