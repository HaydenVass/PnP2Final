﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingExercise7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();

            Menu mainMenu = new Menu();
        }
    }
}
