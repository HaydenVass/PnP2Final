﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingExercise7
{
    class Menu
    {
        private string _switchVar;
        bool running = true;
        List<string> answers = new List<string>();
        int counter = 1;
        // runs both methods when an instance of menu gets created
        public Menu()
        {
            StoryStart();
            SwitchStatement();
        }


        public void SwitchStatement()
        {
            // switch to see if user wants to play game or not
            do
            {

                switch (_switchVar)
                {
                    case "1":
                        {
                            Story();
                        }
                        break;
                    case "2":
                    case "exit":
                        {
                            Console.WriteLine("good bye");
                            running = false;
                        }
                        break;
                    default:
                        Console.WriteLine("Please choose a valid number");
                        Validation.ConsoleClear();
                        break;
                }
            } while (running == true);

        }
        // promts the user if they want to play game or not
        private void StoryStart()
        {
            Console.WriteLine("Hey! I need help finishing a story. Care to help?\nPress [1] for yes and [2] for no.");
            int input = Validation.GetIntWithinRange(1, 2);
            if (input == 1)
            {
                Console.WriteLine("Thats great! We're going to be doing a madlib! I'm going to ask you for an adjectives, nouns, and verbs. At the end " +
                    "we'll plug it into a a fun and interesting story. Lets get started!");
                _switchVar = "1";

            }
            else if (input == 2)
            {
                Console.WriteLine("Thats too bad. Maybe next time!");
                _switchVar = "2";
            }
        }
        // takes in all the user input from the answer list and plugs them into the the story and prints it to the console
        private void Story()
        {
            Input();
            Console.WriteLine($"Today I went to the zoo and saw a {answers.ElementAt(0)} {answers.ElementAt(1)} jumping up and down in its tree." +
                $" He {answers.ElementAt(2)} {answers.ElementAt(3)} through the large tunnel that led to its {answers.ElementAt(4)} {answers.ElementAt(5)}. " +
                $"I got some peanuts and passed them through the cage to a gigantic gray {answers.ElementAt(6)} towering above my head." +
                $" Feeding that animal made me hungry. I went to get a {answers.ElementAt(7)} scoop of icecream. It filled my stomach. After wards " +
                $"I had to {answers.ElementAt(7)} {answers.ElementAt(8)} to catch our bus. When I got home I {answers.ElementAt(9)} my mom " +
                $"for a {answers.ElementAt(11)} day at the zoo.");

            Console.WriteLine("\n");
            Console.WriteLine("What a great story! Thanks for all your help. Till next time!");
            running = false;
        }
        // promts user for a noun, tells them what it is, then saves it to the answers list
        private void Noun()
        {
            Console.WriteLine($"Help {counter}/ 12: Please provide the story a noun.");
            Console.WriteLine("Incase you're wondering. A noun is a person, place, thing, or concept.");
            string input = Validation.NullOrEmpty(Console.ReadLine().ToLower());
            answers.Add(input);
            counter++;
            Validation.ConsoleClear();


        }
        // promts user for a adjective, tells them what it is, then saves it to the answers list

        private void Adjective()
        {
            Console.WriteLine($"Help {counter}/ 12: Please provide the story an adjective.");
            Console.WriteLine("Just in case you dont know. An adjective is a word or phrase naming an attribute," +
                " added to or grammatically related to a noun to modify or describe it.");
            string input = Validation.NullOrEmpty(Console.ReadLine().ToLower());
            answers.Add(input);
            counter++;
            Validation.ConsoleClear();

        }
        // promts user for a verb, tells them what it is, then saves it to the answers list

        private void Verb()
        {
            Console.WriteLine($"Help {counter}/ 12: Please provide the story a verb");
            Console.WriteLine("Just in case you dont know. A verb is a part of speech which is used to demonstrate an action or a state of being.");
            string input = Validation.NullOrEmpty(Console.ReadLine().ToLower());
            answers.Add(input);
            counter++;
            Validation.ConsoleClear();

        }
        // promts user for a past tense verb, tells them what it is, then saves it to the answers list

        private void VerbPastTense()
        {
            Console.WriteLine($"Help {counter}/ 12: Please provide the story a past tense verb, but past tense this time.");
            Console.WriteLine("Just in case you dont know. A verb is a part of speech which is used to demonstrate a past action or a state of past being.");
            string input = Validation.NullOrEmpty(Console.ReadLine().ToLower());
            answers.Add(input);
            counter++;
            Validation.ConsoleClear();

        }
        // promts user for a adverb, tells them what it is, then saves it to the answers list

        private void Adverb()
        {
            Console.WriteLine($"Help {counter}/ 12: Please provide the story a adverb, but past tense this time.");
            Console.WriteLine("Just in case you dont know. An adverb a word or phrase that modifies or qualifies an adjective, verb, " +
                "or other adverb or a word group, expressing a relation of place, time, circumstance, manner, cause, degree, etc. ");
            string input = Validation.NullOrEmpty(Console.ReadLine().ToLower());
            answers.Add(input);
            counter++;
            Validation.ConsoleClear();
        }
        // runs through each option the user has to fill in. Takes in answers and saves them to the answers list.
        private void Input()
        {
            Console.WriteLine("Before we make this story, please answer these fill these out.");
            Validation.ConsoleClear();
            Adjective();
            Noun();
            VerbPastTense();
            Adverb();
            Adjective();
            Noun();
            Noun();
            Adjective();
            Verb();
            Adverb();
            VerbPastTense();
            Adjective();
            Console.WriteLine("Great! Now thats out of the way. Lets see the story you made!");
            Validation.ConsoleClear();
        }
    }
}
