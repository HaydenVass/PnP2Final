﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingExercise8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            // instansiates class with mulidimensional array
            _2Dspace newSpace = new _2Dspace();
            // sets values for the ASCII characters 
            string[] ASCIIarray = {"-", "#", " ", "?", "~", "^" };
            // sets new array with values pulled from the grid from the 2Dspace class
            int[,] space = newSpace.Space();

            // nested for loops to run through the row. 
            for (int row = 0; row < space.GetLength(0); row++)
            {
               Console.WriteLine("");
                // loop to run through the column. Sets the number at that grid position to temp, switch statement runs off temp.
                for (int col = 0; col < space.GetLength(1); col++)
                {
                    int temp = space[row, col];
                    //Console.Write(temp);
                    switch (temp)
                    {
                        case 0: Console.Write(ASCIIarray[0]); break;
                        case 1: Console.Write(ASCIIarray[1]); break;
                        case 2: Console.Write(ASCIIarray[2]); break;
                        case 3: Console.Write(ASCIIarray[3]); break;
                        case 4: Console.Write(ASCIIarray[4]); break;
                        case 5: Console.Write(ASCIIarray[5]); break;
                    }
                }
            }










        }
    }
}
