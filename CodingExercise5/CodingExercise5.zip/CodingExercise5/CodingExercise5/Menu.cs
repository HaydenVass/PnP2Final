﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CodingExercise5
{
    class Menu
    {
        private bool running = true;
        private string choice;
        private string computerSelection;
        private List<string> choices = new List<string>();
        Random random = new Random();
        int playerScore;
        int computerScore;
        int tieScore;
        int gameCounter = 0;


        public Menu()
        {
            AddList();
            Console.WriteLine("How to play");
            SwitchStatement();
            
        }

        public void SwitchStatement()
        {

            do
            {
                if (gameCounter == 10)
                {
                    if (playerScore > computerScore && playerScore > tieScore && gameCounter == 10)
                    {
                        Console.WriteLine($"Conrats! The player has won! Score: {playerScore}");
                    }
                    else if (computerScore > playerScore && computerScore > tieScore && gameCounter== 10)
                    {
                        Console.WriteLine($"Looks like the player has lost this round. Score: {playerScore}");
                    }
                    else if (tieScore > playerScore && tieScore > computerScore && gameCounter == 10)
                    {
                        Console.WriteLine($"Looks like its going to stay a tie. Score {playerScore}");
                    }
                    Console.WriteLine("Play again?\n1 for yes\n2 for no");
                    int replay = Validation.GetIntWithinRange(1, 2);
                    if (replay == 1)
                    {
                        playerScore = 0;
                        computerScore = 0;
                        gameCounter = 0;

                    }
                    else if (replay == 2)
                    {
                        running = false;
                    }
                }
                else
                {
                    Console.WriteLine("Spock is signified with the Star Trek Vulcan salute, while lizard is shown by forming the hand into a sock-puppet-like mouth." +
                                      " Spock smashes scissors and vaporizes rock;" +
                                      " he is poisoned by lizard and disproven by paper. " +
                                      "Lizard poisons Spock and eats paper; it is crushed by rock" +
                                      " and decapitated by scissors. The rest of pieces play as normal rock paper scissors." +
                                      "Who ever has the most points after 10 rounds wins.");
                    Console.WriteLine("------------");
                    Console.WriteLine($"Player Score: {playerScore}\nComputer Score: {computerScore}\nTies: {tieScore}");
                    Console.WriteLine("------------");
                    Display();
                    switch (choice)
                    {
                        case "spock":
                            {
                                PlayerCondition("spock", "scissors", "rock", "lizard", "paper");
                                Validation.ConsoleClear();
                            }
                            break;
                        case "paper":
                            {
                                PlayerCondition("paper", "rock", "spock", "scissors", "lizard");
                                Validation.ConsoleClear();

                            }
                            break;
                        case "scissors":
                            {
                                PlayerCondition("scissors", "paper", "lizard", "spock", "rock");
                                Validation.ConsoleClear();
                            }
                            break;
                        case "rock":
                            {


                                PlayerCondition("rock", "scissors", "lizard", "paper", "spock");
                                Validation.ConsoleClear();
                            }
                            break;
                        case "lizard":
                            {
                                PlayerCondition("lizard", "paper", "spock", "rock", "scissors");
                                Validation.ConsoleClear();
                            }
                            break;
                        case "exit":
                            {
                                Console.WriteLine("good bye");
                                running = false;
                            }
                            break;
                        default:
                            Console.WriteLine("Please choose a valid sign.");
                            Validation.ConsoleClear();
                            break;

                    }
                } 
            }while (running == true) ;


        }
        
        private void PlayerCondition(string playerChoice, string win1, string win2, string lose1, string lose2)
        {
            ComputerChoice();
            if( choice == playerChoice && computerSelection == win1 || choice == playerChoice && computerSelection == win2)
            {
                Console.WriteLine("Player Wins!");
                playerScore++;
            }
            else if (choice == playerChoice && computerSelection == lose1 || choice == playerChoice && computerSelection == lose2)
            {
                Console.WriteLine("Computer Wins!");
                computerScore++;
            }
            else
            {
                Console.WriteLine("its a tie!");
                tieScore++;
            }
            Console.WriteLine($"The computer chose {computerSelection}");
            gameCounter++;
        }

        private void Display()
        {
            Console.WriteLine("Please type the sign you wish to play?");
            foreach(string choice in choices)
            {
                Console.WriteLine(choice);
            }
            Console.WriteLine("---------------");
            choice = Validation.NullOrEmpty(Console.ReadLine().ToLower());
        }
        private void ComputerChoice()
        {
            computerSelection = choices.ElementAt(random.Next(0,4));
          
        }
        private void AddList()
        {
            choices.Add("spock");
            choices.Add("rock");
            choices.Add("scissors");
            choices.Add("lizard");
            choices.Add("paper");

        }

    }
}
